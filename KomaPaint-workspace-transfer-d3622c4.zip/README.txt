KomaPaint workspace transfer, not a Windows executable

This archive contains the actual contents of all Git-visible modified and untracked files, plus the tracked diff and SHA-256 manifest. It does not contain .git or ignored/transient files. Read files/docs/DEVELOPMENT_HANDOVER.md and files/docs/WORKSPACE_CHANGE_INVENTORY.md.

Safe transfer: verify the archive checksum supplied by the sender, then verify each files/<path> entry against MANIFEST.json. In the destination, confirm the allowed branch, exact base commit and a clean working tree. If the base differs, stop and review/reconcile rather than overwriting. Before any changes, check git apply --check tracked-changes.patch and ensure all paths marked untracked are absent. Apply the patch and copy only untracked entries without overwriting existing paths, retaining relative paths and modes. Verify every resulting file SHA-256 against the manifest. No archive extraction should overwrite the destination blindly.
